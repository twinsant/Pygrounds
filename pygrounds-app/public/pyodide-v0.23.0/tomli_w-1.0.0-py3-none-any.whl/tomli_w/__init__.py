__all__ = ("dumps", "dump")
__version__ = "1.0.0"  # DO NOT EDIT THIS LINE MANUALLY. LET bump2version UTILITY DO IT

from tomli_w._writer import dump, dumps
